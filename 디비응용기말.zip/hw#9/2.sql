create or replace trigger StarPlays_Trigger
instead of insert or update or delete on StarPlays
for each row
declare
    type addr_ty is table of varchar2(100);
    city addr_ty := addr_ty('서울', '부산', '대구', '울산', '대전', '광주');
    gu   addr_ty := addr_ty('동', '서', '남', '북', '수영', '해운대', '동작', '사하');
    dong addr_ty := addr_ty('대연1', '대연2', '대연3', '용호', '대잠', '노량', '우', '반여');
    
    cnt1     number;
    cnt2     number;
    max_producerno  movie.producerno%type;
    random_addr        moviestar.address%type;
    young_gender    moviestar.gender%type;
    random_birthdate   moviestar.birthdate%type;
begin --1
    select count(*) into cnt1 from movie
    where title = :new.title and year = :new.year;
    if cnt1 = 0 then
        select * into max_producerno from(
            select producerno 
            from movie
            group by producerno
            having count(*) =(
                select max(count(*))
                from movie
                group by producerno)
        )where rownum = 1;
        insert into movie(title, year, producerno) 
            values(:new.title, :new.year, max_producerno);
    end if;
    --2
    select count(*) into cnt2 from moviestar
    where name = :new.name;
    if cnt2 = 0 then    
    random_addr := city(dbms_random.value(1, city.last))||'시 '||            
                gu(dbms_random.value(1, gu.last))||'구 '||
                dong(dbms_random.value(1, dong.last))||'동 ';   
                
    select count(*) into cnt2 from moviestar
    where name = :new.name;
        select * into young_gender from(
            select gender
            from(
                select gender
                from moviestar
                where birthdate = (
                    select max(birthdate)
                    from moviestar)
                order by dbms_random.value)
            where rownum =1);            
        
    random_birthdate := to_date('1980-01-01')+trunc(dbms_random.value(1,39*365));
    
    insert into moviestar(name, address, gender, birthdate)
            values (:new.name, random_addr, young_gender, random_birthdate);     
    end if;
end;