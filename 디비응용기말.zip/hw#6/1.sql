declare   
    type movie_rec_ty is record(
        title movie.title%type,
        year movie.year%type
    );
    type s_ty is table of movie_rec_ty;
    type r_ty is record(
        name moviestar.name%type,
        movies s_ty
    ); 
    type mv_ty is table of r_ty;  
    mvs mv_ty := mv_ty();  

    cursor csr_st is
        select starname from starsin; 

begin
    for actor_rec in csr_st loop
        declare
            actor_movies s_ty := s_ty();
            movie_count integer := 0;
            cursor csr_movies is
                select m.title, m.year from movie m
                join starsin s on m.title = s.movietitle and m.year = s.movieyear
                where s.starname = actor_rec.starname;
        begin
            for movie_rec in csr_movies loop
                actor_movies.extend; 
                actor_movies(actor_movies.count) := movie_rec;
                movie_count := movie_count + 1;
            end loop;

            mvs.extend;
            mvs(mvs.count).name := actor_rec.starname;
            mvs(mvs.count).movies := actor_movies;

            dbms_output.put('['||mvs.count||']'||mvs(mvs.count).name || ' : '); 

            for i in 1..actor_movies.count loop
                dbms_output.put(actor_movies(i).title || '(' || actor_movies(i).year || '년)'); 
                if i < actor_movies.count then
                    dbms_output.put(', ');
                end if;
            end loop;
            if actor_movies.count>1 then
                dbms_output.put_line('등의 '||movie_count || '편 출연');
            else
            dbms_output.put_line(movie_count || '편 출연');
            end if;        
            end;
    end loop;

end;
