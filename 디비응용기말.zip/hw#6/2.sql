declare
    type s_ty is table of studio%rowtype;
    type movie_ty is record (
        title  varchar2(100),
        year   number
    );
    type mvs_ty is table of movie_ty;
    
    type r_ty is record (
        me       movieexec%rowtype,
        studio   s_ty,
        movie    mvs_ty,
        movie_count number,
        first_movie movie_ty,
        latest_movie movie_ty
    );
    type m_ty is table of r_ty;

    mve m_ty := m_ty();

    cursor csr is select * from movieexec order by name;

    cursor csr_stu(cert movieexec.certno%type) is
        select * from studio where presno = cert;

    cursor csr_mov(cert movieexec.certno%type) is
        select title, year
        from movie
        where cert = producerno
        order by year;

begin
    for m in csr loop
        mve.extend;
        mve(csr%rowcount).me := m;

        open csr_stu(m.certno);
        fetch csr_stu bulk collect into mve(csr%rowcount).studio;
        close csr_stu;

        open csr_mov(m.certno);
        fetch csr_mov bulk collect into mve(csr%rowcount).movie;
        close csr_mov;

        mve(csr%rowcount).movie_count := mve(csr%rowcount).movie.count;
        if mve(csr%rowcount).movie_count > 0 then
            mve(csr%rowcount).first_movie := mve(csr%rowcount).movie(1);
            mve(csr%rowcount).latest_movie := mve(csr%rowcount).movie(mve(csr%rowcount).movie_count);
        end if;
    end loop;

    for i in mve.first..mve.last loop
        dbms_output.put_line('제작자[' || mve(i).me.name || '] : 주소[' ||
                             mve(i).me.address || '], 재산[' || mve(i).me.networth || '원]');

        if mve(i).studio.count = 0 then
            dbms_output.put_line(rpad(' ',3)||'운영 영화사 : 없음');
        else
            dbms_output.put_line(rpad(' ',3)||'운영 영화사 :');
            for j in mve(i).studio.first .. mve(i).studio.last loop
                dbms_output.put_line(rpad(' ',6)||'이름[' || mve(i).studio(j).name || '], 사무실 주소[' || mve(i).studio(j).address || ']');
            end loop;
        end if;

        if mve(i).movie_count = 0 then
            dbms_output.put_line(rpad(' ',3)||'배우 경력 : 해당 없음');
        else
            dbms_output.put_line(rpad(' ',6)||'배우 경력 : 총 영화편수[' || mve(i).movie_count || '편]');
            dbms_output.put_line(rpad(' ',6)||'최초 출연 영화 : ' || mve(i).first_movie.title || '[' || mve(i).first_movie.year || '년]');
            dbms_output.put_line(rpad(' ',6)||'최근 출연 영화 : ' || mve(i).latest_movie.title || '[' || mve(i).latest_movie.year || '년]');
        end if;
    end loop;
end;
