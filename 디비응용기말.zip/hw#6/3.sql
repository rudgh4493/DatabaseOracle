declare
    type r_mvs is record(
        title       movie.title%type,
        year        movie.year%type,
        sname       moviestar.name%type,
        sbirthdate  moviestar.birthdate%type,
        ename       movieexec.name%type,
        enetworth   movieexec.networth%type
    );
    type ary_mvs is table of r_mvs index by varchar(200);

    cursor csr is
        select title, year, ms.name, ms.birthdate, me.name, me.networth
        from movie m, moviestar ms, movieexec me, starsin si
        where m.title= si.movietitle and m.year=si.movieyear
            and si.starname= ms.name and m.producerno= me.certno;
    
    rec r_mvs;
    mvs ary_mvs;
    
    counter number := 1;
    i varchar2(200);
begin
    open csr;
    loop
        fetch csr into rec;
        exit when csr%notfound;
        mvs(rec.title || rec.year) := rec;
        
    end loop;
    close csr;

    dbms_output.put_line(lpad('영화-출연배우 수', 30)||
        lpad('출연배우(생일)', 55)||lpad('제작자(재산)', 50));

    i := mvs.first;
    
    while i is not null loop
        dbms_output.put_line(rpad(mvs(i).title||'('||mvs(i).year||')', 50)||
        rpad('- '||mvs(i).sname||'('||mvs(i).sbirthdate||')',50)||
        mvs(i).ename||'('||mvs(i).enetworth||')');
        counter := counter + 1;
        i := mvs.next(i);
    end loop;

end;
