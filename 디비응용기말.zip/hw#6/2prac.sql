declare
    type e_ty is table of studio%rowtype;
    type r_ty is record(
        me  movieexec%rowtype,
        stu  e_ty
    );
    type m_ty is table of r_ty;
    mve m_ty :=m_ty();
    cursor csr is select * from movieexec;
    cursor csr_stu(cert movieexec.certno%type) is
        select * from studio where name in(
            select name 
            from studio
            where presno = cert);
            
begin
    for m in csr loop
        mve.extend;
        mve(csr%rowcount).me :=m;
        open csr_stu(m.certno);
            fetch csr_stu bulk collect into mve(csr%rowcount).stu;
        close csr_stu;
    end loop;
    
    for i in mve.first..mve.last loop
        dbms_output.put_line('제작자['||mve(i).me.name||']'||': 주소['
        ||mve(i).me.address||'], 재산['||mve(i).me.networth||'원]');
        
        
    
    end loop;

end;










