declare   
    type movie_rec_ty is record(
        title movie.title%type,
        year movie.year%type
    );

    type s_ty is table of movie_rec_ty;  -- 영화 정보를 담는 테이블 타입
    type r_ty is record(
        name moviestar.name%type,
        movies s_ty
    ); 
    type m_ty is table of r_ty;   -- 배우와 그 출연 영화 정보를 담는 테이블 타입
    mvs m_ty := m_ty();    -- 배우와 출연 영화 정보를 담을 변수

    cursor csr_st is
        select starname from starsin; -- 모든 출연 배우의 이름을 가져오는 커서

begin
    -- 배우에 대한 정보를 담기 위해 커서를 통해 반복
    for actor_rec in csr_st loop
        -- 각 배우를 위한 레코드 선언
        declare
            actor_movies s_ty := s_ty(); -- 출연한 영화 리스트
            movie_count integer := 0; -- 출연한 영화 수

            -- 배우의 출연한 영화 정보 가져오기
            cursor csr_movies is
                select m.title, m.year from movie m
                join starsin s on m.title = s.movietitle and m.year = s.movieyear
                where s.starname = actor_rec.starname; -- 특정 배우의 영화만 선택
        begin
            -- 영화 정보를 가져와서 저장
            for movie_rec in csr_movies loop
                actor_movies.extend; -- actor_movies를 확장
                actor_movies(actor_movies.count) := movie_rec; -- 영화 정보를 추가
                movie_count := movie_count + 1; -- 영화 수 증가
            end loop;

            -- 배우 정보 및 출연한 영화 출력
            mvs.extend; -- mvs를 확장
            mvs(mvs.count).name := actor_rec.starname; -- 배우 이름 저장
            mvs(mvs.count).movies := actor_movies; -- 출연 영화 리스트 저장

            dbms_output.put('['||mvs.count||']'||mvs(mvs.count).name || ' : '); -- 배우 이름 출력

            -- 출연한 영화 제목 출력
            for i in 1..actor_movies.count loop
                dbms_output.put(actor_movies(i).title || '(' || actor_movies(i).year || '년)'); -- 영화 제목 및 연도 출력
                if i < actor_movies.count then
                    dbms_output.put(', '); -- 마지막 영화가 아닐 경우 쉼표 추가
                end if;
            end loop;
            dbms_output.put_line(movie_count || '편 출연 : '); -- 출연한 영화 수 출력
        end;
    end loop;

end;
