drop table temp cascade constraints;
drop table test cascade constraints;

create table test (
    name    varchar(100) primary key,
    age     number(3) not null,
    address varchar(200),
    check(age > 10 and age < 110)
);

create table temp (
    num     number(3) primary key,
    name    varchar(100) references test(name)
);

insert into test values ('H0', 23, '부산시 남구');
insert into temp values (0, 'H0');

declare
    type n_type is table of test.name%type;
    type a_type is table of test.age%type;

    test_n   n_type := n_type('H1', 'H2', 'H3', 'H3', 'H4');
    test_a   a_type := a_type(30, NULL, 28, 40, 5);
    temp_n   n_type := n_type();

    sql_str  varchar(200) := 'insert into test values (:1, :2, :3)';
    sql_str1 varchar(200) := 'insert into temp values (:1, :2)';
----------
    integrity_constraints_childrecord exception;
    integrity_constraints_parentkey exception;
    dup_val_on_index exception;
    check_constraints exception;
    null_insert exception;
    pragma exception_init(integrity_constraints_childrecord, -2292);
    pragma exception_init(integrity_constraints_parentkey, -2291);
    pragma exception_init(dup_val_on_index, -0001);
    pragma exception_init(check_constraints, -2290);
    pragma exception_init(null_insert, -1400);
begin
    temp_n := test_n;

    for i in test_n.first..test_n.last loop
        begin
            execute immediate sql_str using test_n(i), test_a(i),
                dbms_random.string('x', 5) || ' ' || dbms_random.string('a', 10);
            execute immediate sql_str1 using i, temp_n(i);

            if i = test_n.first then
                delete from test
                where name = test_n(i);
            elsif i = 3 then
                update temp
                set name = 'H5'
                where num = 3;
            end if;

        exception
            when integrity_constraints_childrecord then
                dbms_output.put_line(i ||': ['||sqlcode||
                    '] 무결성 제약조건이 위배되었습니다 - 자식 레코드가 발견됨');
                
            when integrity_constraints_parentkey then
                dbms_output.put_line(i ||': ['||sqlcode||
                    '] 무결성 제약조건이 위배되었습니다 - 부모 키가 없음');
       
            when dup_val_on_index then
                dbms_output.put_line(i ||': ['||sqlcode||
                    '] 무결성 제약조건이 위배되었습니다 - 중복된 값');
                
            when check_constraints then
                dbms_output.put_line(i ||': ['||sqlcode||
                    '] 체크 제약조건이 위배되었습니다');
                
            when null_insert then
                dbms_output.put_line(i ||': ['||sqlcode||
                    '] NULL을 안에 삽입할 수 없습니다');
        end;
    end loop;

    dbms_output.put_line(lpad(' ', 50, '*'));
    for t in (select * from test) loop
        dbms_output.put_line(t.name || ', ' || t.age || ', ' || t.address);
    end loop;

    dbms_output.put_line(lpad(' ', 50, '*'));
    for t in (select * from temp) loop
        dbms_output.put_line(t.num || ', ' || t.name);
    end loop;
end;
/
