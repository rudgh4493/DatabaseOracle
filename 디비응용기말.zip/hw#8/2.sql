create or replace trigger star_insert
before insert or update on moviestar
for each row
declare
    type addr_ty is table of varchar2(100);
    city addr_ty := addr_ty('서울', '부산', '대구', '울산', '대전', '광주');
    gu   addr_ty := addr_ty('동', '서', '남', '북', '수영', '해운대', '동작', '사하');
    dong addr_ty := addr_ty('대연1', '대연2', '대연3', '용호', '대잠', '노량', '우', '반여');
    
    male_cnt    integer;
    female_cnt  integer;
    random_date date;
    random_addr varchar2(200);
    
begin
    if :new.address is null then
    random_addr := city(dbms_random.value(1, city.last))||'시 '||            
                gu(dbms_random.value(1, gu.last))||'구 '||
                dong(dbms_random.value(1, dong.last))||'동 ';   
        :new.address := random_addr;
    end if;
    
    if :new.birthdate is null then 
        random_date := to_date('1900-01-01')+trunc(dbms_random.value(1,120*365));
        :new.birthdate := random_date;    
    end if;
    
    if :new.gender is null then
        select (select count(*) from moviestar where gender='male' and birthdate > :NEW.birthdate),
            (select count(*) from moviestar where gender='female' and birthdate > :NEW.birthdate)
        into male_cnt, female_cnt
        from dual;
            
        if male_cnt > female_cnt then
            :new.gender :='male';
        elsif male_cnt < female_cnt then
            :new.gender :='female';
        else
            if dbms_random.value(0,1) < 0.5 then
                :new.gender :='male';
            else
                :new.gender :='female';
            end if;
        end if;
    end if;   
end;
    