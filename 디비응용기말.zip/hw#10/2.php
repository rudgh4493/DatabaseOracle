<?php
function p_error() {
    $e = oci_error();
    print htmlentities($e['message']);
    exit();
}
$conn = oci_connect("db2020575054","db99304493", "localhost/course");
if (!$conn)    p_error();

$stmt = oci_parse($conn,
        " select name from studio order by name ");
//	" select name, count(*) as cnt from movie, studio ".
//        " where name= studioname group by name order by name ");
if (!$stmt)    p_error();
if (!oci_execute($stmt)) p_error ();

print "<TABLE bgcolor=#E7FEFF border=3 cellspacing=3>\n";
print "<TR bgcolor=#7DDAFF align=center> ".
        " <TH> 영화사 <TH> 제작한 영화수 </TR>\n";

while ($row = oci_fetch_array($stmt)) {
    $studio = $row['NAME'];
    
    print "<tr> <td> "
        . " <a target='_blank' href='stu_info.php?studio=$studio'> $studio </a>";
    $stmt_movie_cnt= oci_parse($conn,
	" select count(*) as cnt from movie ".
        " where studioname ='$studio' ");
    if (!$stmt_movie_cnt)    p_error();
    if (!oci_execute($stmt_movie_cnt)) p_error ();
    $movie_cnt = oci_fetch_array($stmt_movie_cnt)[0];
    if($movie_cnt > 0){
        print " <td> "
            . "<a target='_blank' href='movie_info.php?studio=$studio'> $movie_cnt </a>";
    }
    else{
        print " <td> 0 ";
    }
 // 
    
//    
//   print "<td> <a target=_blank href='stu_info.php?studio=$studio> $studio </a> ". 
//          "<td> $count  </tr>";
   print " </tr>";
}
print "</tabel>";
oci_free_statement($stmt);
oci_close($conn);
?>
