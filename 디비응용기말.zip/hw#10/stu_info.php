<?php
function p_error() {
    $e = oci_error();
    print htmlentities($e['message']);
    exit();
}
$conn = oci_connect("db2020575054","db99304493", "localhost/course");
if (!$conn)    p_error();

$studio = $_GET["studio"];

$stmt = oci_parse($conn,
	"select s.name stuname, s.address stuaddr, e.name presname, "
        . " e.address presaddr, networth from studio s, movieexec e "
	. " where certno = presno and s.name = '$studio' ");
if (!$stmt)    p_error();
if (!oci_execute($stmt)) p_error ();

print "<TABLE bgcolor=#E7FEFF border=3 cellspacing=3>\n";
print "<TR bgcolor=#7DDAFF align=center><TH> 영화사 <TH> 주소 <TH> 사장 <TH> 사장의 주소 <TH> 재산액수 </TR>\n";

while ($row = oci_fetch_array($stmt)) {
    print " <TR> <TD> {$row['STUNAME']} <TD> {$row['STUADDR']} <TD> {$row['PRESNAME']} "
        . " <TD> {$row['PRESADDR']} <TD> {$row['NETWORTH']} </TR>\n";
}
print "</TABLE>\n";

oci_free_statement($stmt);
oci_close($conn);
?>
