<?php
function p_error() {
    $e = oci_error();
    print htmlentities($e['message']);
    exit();
}
$conn = oci_connect("db2020575054","db99304493", "localhost/course");
if (!$conn)    p_error();

$stmt = oci_parse($conn,
	" select title, year, length, producerno, studioname ".
        " from movie ".
        " order by year, length ");
if (!$stmt)    p_error();
if (!oci_execute($stmt)) p_error ();

print "<TABLE bgcolor=#E7FEFF border=1 cellspacing=2>\n";
print "<TR bgcolor=#7DDAFF align=center><TH> 제목 <TH> 년도".
      " <TH> 상영시간 <th> 제작자 <th> 영화사사장 <th> 출연배우수 <th> 출연배우진 </TR>\n";

while ($row = oci_fetch_array($stmt)) {
    $title = $row['TITLE'];
    $year = $row['YEAR'];
    $length = $row['LENGTH'];
    $producerno = $row['PRODUCERNO'];
    $studio= $row['STUDIONAME'];
    $title2 = str_replace("'", "''", $title);
    
    
    print "<TR> <TD> $title2 <TD> {$year}년 <TD> {$length}분 ";
    
    $stmt_producer = oci_parse($conn,
	" select name from movie, movieexec".
        " where certno = producerno and producerno = '$producerno'");
    if (!$stmt_producer)    p_error();
    if (!oci_execute($stmt_producer)) p_error ();
    $producer = oci_fetch_array($stmt_producer)[0];
    
    $stmt_president = oci_parse($conn,
	" select me.name from movieexec me, studio s ".
        " where certno= presno and s.name= '$studio'");
    if (!$stmt_president)    p_error();
    if (!oci_execute($stmt_president)) p_error ();
    $presidnet = oci_fetch_array($stmt_president)[0];
         
    $stmt_starcnt = oci_parse($conn,
	" select count(starname), title, year from movie, starsin".
        " where movietitle = '$title2' and movieyear= '$year' ".
        " group by title, year ");
    if (!$stmt_starcnt)    p_error();
    if (!oci_execute($stmt_starcnt)) p_error ();
    $star_cnt = oci_fetch_array($stmt_starcnt)[0];
    if ($star_cnt === NULL) {
        $star_cnt = "정보없음";
    } else {
        $star_cnt .= "명";
    }   
    print "<td> $producer ";
    print "<td> $presidnet ";
    print "<td> $star_cnt ";
    
    $stmt_star = oci_parse($conn, 
        " select starname, birthdate from starsin, moviestar ".
        " where movietitle= '$title2' and movieyear= '$year' ". 
        " and name=starname order by birthdate desc ");
    if (!$stmt_star)    p_error();
    if (!oci_execute($stmt_star)) p_error();
    print "<td>";
    $first = true;
    $star_found = false;

    while($star = oci_fetch_array($stmt_star)){
        $moviestar = $star[0];
        if ($moviestar === NULL) {
            $moviestar = "정보없음"; 
        }
        if (!$first){
            print ",<br> ";
        }
        print "$moviestar";     
        $first = false;
        $star_found = true; 
    }

    if (!$star_found) {
        print "정보없음";
    }
        print "</tr>\n";
    }
    print "</TABLE>\n";

oci_free_statement($stmt);
oci_free_statement($stmt_producer);
oci_free_statement($stmt_president);
oci_close($conn);
?>
