<?php
function p_error() {
    $e = oci_error();
    print htmlentities($e['message']);
    exit();
}
$conn = oci_connect("db2020575054","db99304493", "localhost/course");
if (!$conn)    p_error();

$studio = $_GET["studio"];

$stmt = oci_parse($conn,
	"select title, year, length, name, studioname from movie, movieexec ".
	" where certno = producerno and studioname = '$studio' ");
if (!$stmt)    p_error();
if (!oci_execute($stmt)) p_error ();

print "<TABLE bgcolor=#E7FEFF border=3 cellspacing=3>\n";
print "<TR bgcolor=#7DDAFF align=center><TH> 제목 <TH> 개봉년도 <TH> 상영시간 "
    . "<TH> 제작자 이름 </TR>\n";

while ($row = oci_fetch_array($stmt)) {
    print "<TR> <TD> {$row['TITLE']} <TD> {$row['YEAR']} <TD> {$row['LENGTH']} "
    . "<TD> {$row['NAME']}  </TR>\n";
}
print "</TABLE>\n";

oci_free_statement($stmt);
oci_close($conn);
?>
