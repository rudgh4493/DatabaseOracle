select name, producerno from movie, movieexec where certno = producerno order by producerno;
select movieexec.name, presno from studio, movieexec where certno = presno;
select name, certno from movieexec;

        select count(*)
        from movieexec;

select * from movieexec
where name like 'a%';      

select * from movieexec; 

update movieexec
set name= null
where certno = 2;

insert into movieexec(name,networth,certno) values ('a2',1234,61);






        select max(networth) 
        from movieexec;