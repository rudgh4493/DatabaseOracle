<?php

function p_error($message = "Error") {
    $e = oci_error();
    print "<b style='color:red;'>$message</b>: " . htmlentities($e['message']) . "<br>";
    exit();
}

$conn = oci_connect("db2020575054", "db99304493", "localhost/course");
if (!$conn) p_error("[Connection Error]");

$stmt = oci_parse($conn, "
    SELECT e.name AS name, e.address AS addr, s.name AS studio
    FROM movieexec e
    LEFT JOIN studio s ON s.presno = e.certno
    ORDER BY e.name
");
if (!$stmt || !oci_execute($stmt)) p_error("[Query Execution Error]");

print "<table border='1' bgcolor=#E7FEFF cellspacing='2' cellpadding='5' style='border-collapse: collapse;'>";
print "<tr style='background-color:#7DDAFF; text-align:center;'>
            <th>순번 <th>이름 <th>주소 <th>영화사 <th>제작 영화 <th>출연 영화 </tr>";

$count = 0;
while ($row = oci_fetch_array($stmt, OCI_ASSOC)) {
    $count++;
    $name = $row['NAME'];
    $addr = $row['ADDR'];
    $studio = $row['STUDIO'] ?: "없음";

    // 제작 영화 수
    $stmt_prodcnt = oci_parse($conn, "
        SELECT COUNT(*)
        FROM movieexec e
        JOIN movie m ON e.certno = m.producerno
        WHERE e.name = :name
    ");
    oci_bind_by_name($stmt_prodcnt, ":name", $name);
    if (!$stmt_prodcnt || !oci_execute($stmt_prodcnt)) p_error("[Production Count Error]");
    $prodcnt = oci_fetch_array($stmt_prodcnt)[0];

    // 출연 영화 수
    $stmt_appearcnt = oci_parse($conn, "
        SELECT COUNT(*)
        FROM starsin si
        JOIN movie m ON si.movietitle = m.title AND si.movieyear = m.year
        WHERE si.starname = :name
    ");
    oci_bind_by_name($stmt_appearcnt, ":name", $name);
    if (!$stmt_appearcnt || !oci_execute($stmt_appearcnt)) p_error("[Appearance Count Error]");
    $appearcnt = oci_fetch_array($stmt_appearcnt)[0];

    // 제작 영화 목록
    $stmt_prodmvs = oci_parse($conn, "
        SELECT m.title, m.year
        FROM movieexec e
        JOIN movie m ON e.certno = m.producerno
        WHERE e.name = :name
    ");
    oci_bind_by_name($stmt_prodmvs, ":name", $name);
    if (!$stmt_prodmvs || !oci_execute($stmt_prodmvs)) p_error("[Production Movies Error]");

    // 출연 영화 목록
    $stmt_appearmvs = oci_parse($conn, "
        SELECT m.title, m.year
        FROM starsin si
        JOIN movie m ON si.movietitle = m.title AND si.movieyear = m.year
        WHERE si.starname = :name
    ");
    oci_bind_by_name($stmt_appearmvs, ":name", $name);
    if (!$stmt_appearmvs || !oci_execute($stmt_appearmvs)) p_error("[Appearance Movies Error]");

    // 최대 행 계산
    $max_rows = max($prodcnt, $appearcnt, 1);

    // 첫 행 출력
    print "<tr>";
    print "<td style='background-color:2197ff; color:white;' rowspan='$max_rows'>$count</td>";
    print "<td rowspan='$max_rows'>$name</td>";
    print "<td rowspan='$max_rows'>$addr</td>";
    print "<td rowspan='$max_rows'>$studio</td>";

    // 영화 정보 출력
    $produced_movies = [];
    while ($movie = oci_fetch_array($stmt_prodmvs, OCI_ASSOC)) {
        $produced_movies[] = htmlentities("{$movie['TITLE']} ({$movie['YEAR']})", ENT_QUOTES);
    }

    $appeared_movies = [];
    while ($movie = oci_fetch_array($stmt_appearmvs, OCI_ASSOC)) {
        $appeared_movies[] = htmlentities("{$movie['TITLE']} ({$movie['YEAR']})", ENT_QUOTES);
    }

    for ($i = 0; $i < $max_rows; $i++) {
        if ($i > 0) print "<tr>";
        print "<td>" . ($produced_movies[$i] ?? "<span style='color:red;'>없음</span>") . "</td>";
        print "<td>" . ($appeared_movies[$i] ?? "<span style='color:red;'>없음</span>") . "</td>";
        print "</tr>";
    }
}

print "</table>";

oci_free_statement($stmt);
oci_close($conn);
?>
