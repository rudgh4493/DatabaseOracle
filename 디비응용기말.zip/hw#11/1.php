<?php
function p_error() {
    $e = oci_error();
    print "<b>Error</b> : " . htmlentities($e['message']) . "<br>";
    exit();
}

$conn = oci_connect("db2020575054", "db99304493", "localhost/course");
if (!$conn) p_error();


$title = str_replace("'", "''", $_POST["title"]);
$title_compare_option = $_POST['title_compare_option'];
$title_case_sensitive = $_POST['title_case_sensitive'];
$title1  = str_replace(['%'], ['\%'], $title);
$length_min = $_POST['length_min'];
$length_max = $_POST['length_max'];
$actor_year = $_POST['actor_year'];
$actor_gender = $_POST['actor_gender']; 


$sql = " select distinct m.title, m.year, m.length, me.name as producer_name, s.name as studio_name, s.address as studio_address
        from movie m
        join studio s on m.studioname = s.name
        join movieexec me on m.producerno = me.certno
        left join starsin si on m.title = si.movietitle and m.year = si.movieyear
        left join moviestar ms on si.starname = ms.name
        where 1=1";

if (!empty($title1)) {
    if ($title_compare_option === 'yes') {
        $sql = $sql .= $title_case_sensitive
            ? " and title like '%$title1%' escape '\\' "
            : " and lower(title) like lower('%$title1%') escape '\\' ";
    } else {
        $sql = $sql .= $title_case_sensitive
            ? " and title = '$title1' escape '\\' "
            : " and lower(title) = lower('$title1') escape '\\' ";
    }
}

if (!empty($length_min)) {
    $sql = $sql." and length >= '$length_min' ";
}
if (!empty($length_max)) {
    $sql = $sql." and length <= '$length_max' ";
}

if (!empty($actor_year)) {
    $sql = $sql ." and ms.birthdate > to_date('$actor_year-01-01')";
}
if (!empty($actor_gender)) {
    $sql = $sql . " and ms.gender = '$actor_gender'";
}

$sql = $sql .= " order by title, year";

$stmt = oci_parse($conn, $sql);
if (!$stmt) p_error();

if (!oci_execute($stmt)) p_error();

print "<TABLE bgcolor=#E7FEFF border=1 cellspacing=2>\n";
print "<TR bgcolor=#7DDAFF align=center>
        <TH>제목</TH>
        <TH>연도</TH>
        <TH>상영시간</TH>
        <TH>제작자</TH>
        <TH>영화사 이름</TH>
        <TH>영화사 주소</TH>
      </TR>\n";

while ($row = oci_fetch_array($stmt, OCI_ASSOC)) {
    $highlighted_title = $row['TITLE'];
    
    // 검색어 강조 (특수 문자 처리 포함)
    if (!empty($title)) {
        $highlighted_title = preg_replace(
            '/' . preg_quote($title, '/') . '/i', 
            "<span style='color:red;'>$0</span>", 
            $row['TITLE']
        );
    }

    print "<TR>";
    print "<TD>$highlighted_title</TD>";
    print "<TD>{$row['YEAR']}</TD>";
    print "<TD>{$row['LENGTH']}</TD>";
    print "<TD>{$row['PRODUCER_NAME']}</TD>";
    print "<TD>{$row['STUDIO_NAME']}</TD>";
    print "<TD>{$row['STUDIO_ADDRESS']}</TD>";
    print "</TR>\n";
}

print "</TABLE>\n";

oci_free_statement($stmt);
oci_close($conn);
?>
