declare
    mv  studioinfo.movies%type;
    st  studioinfo.stars%type;
begin
    for s in (select * from studioinfo) loop
        dbms_output.put_line('영화사: '||s.name||','|| '주소: '||s.address||', 사장: '||s.president);
        mv := s.movies;
        st := s.stars;
        
        if mv.count>0 then
            dbms_output.put_line('      영화 리스트');
            for i in mv.first..mv.last loop
                dbms_output.put_line('      - '||mv(i).title||'('
                    ||mv(i).year||'), 예산: '||mv(i).budget
                    ||', 제작자: '||mv(i).producer);                    
            if st.count >0 then
                     dbms_output.put_line('          출연배우');
                for j in st.first..st.last loop
                     dbms_output.put_line('          - '||st(j).name
                        ||', 계약금액: '||st(j).salary
                        ||', 계약기간: '||st(j).cont_period||'년');
                end loop;
            end if;
            end loop;
        end if;
        dbms_output.put_line('');
        
    end loop;
end;
