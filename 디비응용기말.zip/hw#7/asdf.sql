DECLARE
    -- 스튜디오 정보
    TYPE StudioRec IS RECORD (
        name      VARCHAR2(30),
        address   VARCHAR2(255),
        president VARCHAR2(30)
    );

    studios       SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST('Fox', 'MGM', 'Universal', 'Paramount', 'Warner Bros');
    addresses     SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST('123 Hollywood Blvd', '456 Studio Way', '789 Movie Ave', '101 Production Rd', '202 Film St');
    presidents    SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST('John Doe', 'Jane Smith', 'Michael Lee', 'Alice Johnson', 'David Brown');

    -- 무작위 값에 사용할 변수들
    budget       NUMBER;
    salary       NUMBER;
    cont_period  NUMBER;
    num_stars    NUMBER;
    star_list    star_tab := star_tab();
    movie_list   movie_tab := movie_tab();

    -- 반복문에 사용할 변수
    i            NUMBER;
    j            NUMBER;

BEGIN
    -- 각 스튜디오에 대해 레코드를 삽입하기 위한 반복문
    FOR i IN 1..studios.COUNT LOOP
        -- 각 스튜디오의 무작위 예산 생성 (예: 50,000,000 ~ 500,000,000 사이)
        budget := DBMS_RANDOM.VALUE(50000000, 500000000);

        -- 각 스튜디오마다 별도의 star_list와 movie_list 초기화
        star_list.DELETE;
        movie_list.DELETE;

        -- 각 스튜디오에 대해 무작위로 배우 수 결정 (예: 3 ~ 12명)
        num_stars := TRUNC(DBMS_RANDOM.VALUE(3, 12));

        -- 각 스튜디오에 대해 무작위 값을 가진 배우 목록 생성
        FOR j IN 1..num_stars LOOP
            salary := DBMS_RANDOM.VALUE(100000, 1000000); -- 무작위 계약금 (100,000 ~ 1,000,000 사이)
            cont_period := TRUNC(DBMS_RANDOM.VALUE(1, 10)); -- 무작위 계약 기간 (1~10년 사이)
            
            -- star_list에 추가
            star_list.EXTEND;
            star_list(star_list.COUNT) := star_ty(
                name => 'Random Star ' || DBMS_RANDOM.STRING('x', 5),
                salary => salary,
                cont_period => cont_period
            );
        END LOOP;

        -- 필요에 따라 영화 목록도 무작위로 추가 가능
        movie_list.EXTEND;
        movie_list(1) := mv_ty('Sample Movie', 2023, budget, 'Sample Producer');

        -- 무작위 속성을 가진 스튜디오 레코드 삽입
        INSERT INTO StudioInfo (name, address, president, movies, stars)
        VALUES (
            studios(i),
            addresses(i),
            presidents(i),
            movie_list,
            star_list
        );
    END LOOP;

    COMMIT;
END;
/
DECLARE
    -- 스튜디오 정보
    TYPE StudioRec IS RECORD (
        name      VARCHAR2(30),
        address   VARCHAR2(255),
        president VARCHAR2(30)
    );

    studios       SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST('Fox', 'MGM', 'Universal', 'Paramount', 'Warner Bros');
    addresses     SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST('123 Hollywood Blvd', '456 Studio Way', '789 Movie Ave', '101 Production Rd', '202 Film St');
    presidents    SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST('John Doe', 'Jane Smith', 'Michael Lee', 'Alice Johnson', 'David Brown');

    -- 무작위 값에 사용할 변수들
    budget       NUMBER;
    salary       NUMBER;
    cont_period  NUMBER;
    num_stars    NUMBER;
    star_list    star_tab := star_tab();
    movie_list   movie_tab := movie_tab();

    -- 반복문에 사용할 변수
    i            NUMBER;
    j            NUMBER;

BEGIN
    -- 각 스튜디오에 대해 레코드를 삽입하기 위한 반복문
    FOR i IN 1..studios.COUNT LOOP
        -- 각 스튜디오의 무작위 예산 생성 (예: 50,000,000 ~ 500,000,000 사이)
        budget := DBMS_RANDOM.VALUE(50000000, 500000000);

        -- 각 스튜디오마다 별도의 star_list와 movie_list 초기화
        star_list.DELETE;
        movie_list.DELETE;

        -- 각 스튜디오에 대해 무작위로 배우 수 결정 (예: 3 ~ 12명)
        num_stars := TRUNC(DBMS_RANDOM.VALUE(3, 12));

        -- 각 스튜디오에 대해 무작위 값을 가진 배우 목록 생성
        FOR j IN 1..num_stars LOOP
            salary := DBMS_RANDOM.VALUE(100000, 1000000); -- 무작위 계약금 (100,000 ~ 1,000,000 사이)
            cont_period := TRUNC(DBMS_RANDOM.VALUE(1, 10)); -- 무작위 계약 기간 (1~10년 사이)
            
            -- star_list에 추가
            star_list.EXTEND;
            star_list(star_list.COUNT) := star_ty(
                name => 'Random Star ' || DBMS_RANDOM.STRING('x', 5),
                salary => salary,
                cont_period => cont_period
            );
        END LOOP;

        -- 필요에 따라 영화 목록도 무작위로 추가 가능
        movie_list.EXTEND;
        movie_list(1) := mv_ty('Sample Movie', 2023, budget, 'Sample Producer');

        -- 무작위 속성을 가진 스튜디오 레코드 삽입
        INSERT INTO StudioInfo (name, address, president, movies, stars)
        VALUES (
            studios(i),
            addresses(i),
            presidents(i),
            movie_list,
            star_list
        );
    END LOOP;

    COMMIT;
END;
/
