declare
    sql_ins varchar2(200) := 'insert into StudioInfo 
        values (:1, :2, :3, movie_tab(), star_tab())';
    sql_movie varchar2(200) := 'insert into table (select movies from StudioInfo where name = :1) values (mv_ty(:2, :3, :4, :5))';
    sql_star varchar2(200) := 'insert into table (select stars from StudioInfo where name = :1) values (star_ty(:2, :3, :4))';
    
    type star_ty is table of varchar2(100);
    keys star_ty := star_ty('mark hamill', 'harrison ford', 'joon-hun park'
        , 'emilio estevez', 'dana carvey', 'mike meyers', 'robert redford'
        , 'kim basinger', 'clark gable', 'johnny depp', 'sean connery');
            
        
    cursor csr_movie(stuname studio.name%type) is
        select m.title, m.year, me.name as producer
        from movie m, movieexec me
        where m.producerno = me.certno and m.studioname = stuname;      
        
    ceo_name varchar2(100);


begin
    for s in (select * from studio) loop
        select me.name into ceo_name
        from movieexec me
        where me.certno = s.presno;
    
        execute immediate sql_ins using s.name, s.address, ceo_name;
        for i in csr_movie(s.name) loop
            execute immediate sql_movie using s.name, i.title, i.year,
               dbms_random.value(1000000,10000000000), i.producer;
        end loop;
        for j in 1..dbms_random.value(1,11) loop
            execute immediate sql_star using s.name, keys(dbms_random.value(1, keys.last)),
                dbms_random.value(100000,99999999),dbms_random.value(1,10);
        end loop;
        
    end loop;

end;

