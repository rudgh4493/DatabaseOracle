declare 
    cursor csr is select * from MovieExecInfo;

    mv  MovieExecInfo.movies%type;
    st  MovieExecInfo.studios%type;
    
begin

    for e in (select * from movieexecinfo) loop
        dbms_output.put_line('이름: '||e.name||', '|| '주소: '||e.address||', 자산: '||e.networth);
        mv := e.movies;
        st := e.studios;
        
        if mv.count>0 then
            for i in mv.first..mv.last loop
                dbms_output.put_line('      - '||mv(i).title||'('
                    ||mv(i).year||'), 계약날짜: '||mv(i).contract_date
                    ||', 계약 금액: '||mv(i).salary);  
            if st.count >0 then
                for j in st.first..st.last loop
                    dbms_output.put_line('          - '||st(j).name
                        ||', 직원 수: '||st(j).emp_count);
                end loop;     
            end if;    
            end loop;
        end if;
    dbms_output.put_line('');
    end loop;
        
        
        
end;