declare 
    sql_ins varchar2(200) :='insert into MovieExecInfo
        values (:1, :2, :3, movie_tab(), studio_tab())';
    sql_movie varchar2(200) := 'insert into table 
        (select movies from MovieExecInfo where name = :1) values (movie_ty(:2, :3, :4, :5))';
    sql_studio varchar2(200) :='insert into table 
        (select studios from MovieExecInfo where name = :1) values (studio_ty(:2, :3))';
        
    cursor csr_moviestudio1(mename movieexec.name%type) is
        select m.title, m.year, m.studioname, m.producerno, 
            me.name, me.address, me.certno
        from movie m, movieexec me, studio s
        where m.producerno = me.certno and m.studioname = s.name
            and mename= me.name; 
            
    cursor csr_moviestudio2(mename movieexec.name%type) is
        select m.title, m.year, m.studioname, m.producerno, 
            me.name, me.address, me.certno
        from movie m, movieexec me, studio s
        where m.producerno = me.certno and m.studioname = s.name
            and mename= me.name;      
        
begin
    for e in (select * from movieexec) loop
        execute immediate sql_ins using e.name, e.address, to_number(e.networth);
        
        for i in csr_moviestudio1(e.name) loop
            execute immediate sql_movie using e.name, i.title, to_number(i.year), 
            to_date(to_char(i.year)|| '-01-01', 'yyyy-mm-dd')-trunc(dbms_random.value(1,10*365)),
                trunc(dbms_random.value(10000,10000000000));
       end loop; 
                
        for j in csr_moviestudio2(e.name) loop
            execute immediate sql_studio using e.name,j.studioname, dbms_random.value(1,40000);
       
        end loop;
    end loop;
end; 



