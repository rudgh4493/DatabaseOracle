set serveroutput on size 100000;

declare
  tbl varchar2(100);
  sql_ex  varchar2(200);
  cursor c1 is select type_name from user_types; --  where table_name not like 'BIN%';
begin
  open c1;
  loop
    fetch c1 into tbl;
    exit when c1%NOTFOUND;
    sql_ex := 'drop type ' || tbl || ' force';
    begin
      	execute immediate sql_ex;
    	DBMS_OUTPUT.PUT_LINE(tbl||' was dropped...');
    exception
      when others then
        DBMS_OUTPUT.PUT_LINE('Cannot Drop '||tbl);
    end;
  end loop;
  close c1;
end;
/
quit
