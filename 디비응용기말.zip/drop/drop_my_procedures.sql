declare
  obj_name user_procedures.object_name%type;
  obj_type user_procedures.object_type%type;
  sql_ex  varchar2(200);
  cursor c1 is select object_name, object_type from user_procedures;
begin
  open c1;
  loop
    fetch c1 into obj_name, obj_type;
    exit when c1%NOTFOUND;
    if obj_type = 'PROCEDURE' then
        sql_ex := 'drop procedure ';
    else
        sql_ex := 'drop function ';
    end if;
    sql_ex := sql_ex || obj_name;
    begin
      	execute immediate sql_ex;
    	DBMS_OUTPUT.PUT_LINE(obj_name||' was dropped...');
    exception
      when others then
        DBMS_OUTPUT.PUT_LINE('Cannot Drop '||obj_name);
    end;
  end loop;
  close c1;
end;
/
quit
