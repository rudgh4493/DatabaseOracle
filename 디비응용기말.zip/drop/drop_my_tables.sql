set serveroutput on size 100000;

declare
  tbl user_tables.table_name%type;
  sql_ex  varchar(200);
  cursor c1 is select table_name from user_tables where table_name not like 'BIN%';
begin
  open c1;
  loop
    fetch c1 into tbl;
    exit when c1%NOTFOUND;
    sql_ex := 'drop table ' || tbl || ' cascade constraints purge';
    begin
      	execute immediate sql_ex;
    	DBMS_OUTPUT.PUT_LINE(tbl||' was dropped...');
    exception
      when others then
        DBMS_OUTPUT.PUT_LINE('Cannot Drop '||tbl);
    end;
  end loop;
  close c1;
end;
/
quit
