-- 생성자 Oracle SQL Developer Data Modeler 23.1.0.087.0806
--   위치:        2024-09-25 15:04:24 KST
--   사이트:      Oracle Database 12c
--   유형:   +   Oracle Database 12c



DROP TABLE address CASCADE CONSTRAINTS;

DROP TABLE cartoon CASCADE CONSTRAINTS;

DROP TABLE contracts CASCADE CONSTRAINTS;

DROP TABLE crew CASCADE CONSTRAINTS;

DROP TABLE movie CASCADE CONSTRAINTS;

DROP TABLE movieexec CASCADE CONSTRAINTS;

DROP TABLE moviestar CASCADE CONSTRAINTS;

DROP TABLE murdermystery CASCADE CONSTRAINTS;

DROP TABLE starsin CASCADE CONSTRAINTS;

DROP TABLE studio CASCADE CONSTRAINTS;

drop type family_info force;
drop type exec_info force;
drop type star_info force;
drop type people_info force;


CREATE OR REPLACE TYPE people_info AS OBJECT (
        name      VARCHAR2(50),
        address   VARCHAR2(200),
        birthdate DATE
) NOT FINAL;
/

CREATE OR REPLACE TYPE family_info AS OBJECT (
        spouse   VARCHAR2(50),
        no_child NUMBER(3)
) NOT FINAL;
/

CREATE OR REPLACE TYPE exec_info UNDER people_info (
        networth NUMBER(20),
        role     VARCHAR2(50),
        family   family_info,
        e_no     CHAR(13)
) FINAL;
/

-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

CREATE OR REPLACE TYPE star_info UNDER people_info (
        gender CHAR(6),
        family family_info,
        s_no   CHAR(13)
) FINAL;
/

-- predefined type, no DDL - XMLTYPE

CREATE TABLE address (
    addrid     NUMBER(10) NOT NULL,
    branchname VARCHAR2(50),
    city       VARCHAR2(50) NOT NULL,
    gu         VARCHAR2(50) NOT NULL,
    dong       VARCHAR2(50) NOT NULL,
    detail     VARCHAR2(50) NOT NULL,
    studioname VARCHAR2(50)
);

ALTER TABLE address ADD CHECK ( addrid BETWEEN 1 AND 9999999 );

ALTER TABLE address ADD CONSTRAINT address_pk PRIMARY KEY ( addrid );

CREATE TABLE cartoon (
    title VARCHAR2(100) NOT NULL,
    year  NUMBER(4) NOT NULL
);

ALTER TABLE cartoon ADD CHECK ( year BETWEEN 1920 AND 2024 );

ALTER TABLE cartoon ADD CONSTRAINT cartoon_pk PRIMARY KEY ( title,
                                                            year );

CREATE TABLE contracts (
    salary     NUMBER(20),
    title      VARCHAR2(100) NOT NULL,
    year       NUMBER(4) NOT NULL,
    studioname VARCHAR2(50) NOT NULL,
    starno     CHAR(13) NOT NULL
);

ALTER TABLE contracts ADD CHECK ( year BETWEEN 1920 AND 2024 );

ALTER TABLE contracts ADD CHECK ( starno LIKE '010-____-____' );

ALTER TABLE contracts
    ADD CONSTRAINT contracts_pk PRIMARY KEY ( title,
                                              year,
                                              studioname,
                                              starno );

CREATE TABLE crew (
    "number"   NUMBER(10) NOT NULL,
    studioname VARCHAR2(50) NOT NULL
);

ALTER TABLE crew ADD CHECK ( "number" BETWEEN 1 AND 9999999 );

ALTER TABLE crew ADD CONSTRAINT crew_pk PRIMARY KEY ( "number",
                                                      studioname );

CREATE TABLE movie (
    title       VARCHAR2(100) NOT NULL,
    year        NUMBER(4) NOT NULL,
    length      NUMBER(3),
    incolor     CHAR(1),
    studioname  VARCHAR2(50) NOT NULL,
    origintitle VARCHAR2(100) NOT NULL,
    originyear  NUMBER(4) NOT NULL
);

ALTER TABLE movie ADD CHECK ( year BETWEEN 1920 AND 2024 );

ALTER TABLE movie ADD CHECK ( length BETWEEN 50 AND 300 );

ALTER TABLE movie ADD CHECK ( originyear BETWEEN 1920 AND 2024 );

ALTER TABLE movie ADD CONSTRAINT movie_pkey PRIMARY KEY ( title,
                                                          year );

CREATE TABLE movieexec (
    info    exec_info,
    company VARCHAR2(50),
    CHECK ( info.e_no IS NOT NULL )
);

ALTER TABLE movieexec
    ADD CHECK ( info.family.no_child BETWEEN 50 AND 300 );

ALTER TABLE movieexec ADD CHECK ( info.e_no LIKE '010-____-____' );

ALTER TABLE movieexec ADD CONSTRAINT movieexec_pk PRIMARY KEY ( info.e_no );

ALTER TABLE movieexec ADD CONSTRAINT unique_name UNIQUE ( info.name );

CREATE TABLE moviestar (
    info     star_info,
    stardate DATE,
    CHECK ( info.s_no IS NOT NULL )
);

ALTER TABLE moviestar
    ADD CHECK ( stardate > DATE '1900-01-01'
                AND stardate < DATE '2020-12-31' );

ALTER TABLE moviestar
    ADD CHECK ( info.gender IN ( 'female', 'male' ) );

ALTER TABLE moviestar
    ADD CHECK ( info.family.no_child BETWEEN 50 AND 300 );

ALTER TABLE moviestar ADD CHECK ( info.s_no LIKE '010-____-____' );

ALTER TABLE moviestar ADD CONSTRAINT moviestar_pkey PRIMARY KEY ( info.s_no );

CREATE TABLE murdermystery (
    title  VARCHAR2(100) NOT NULL,
    year   NUMBER(4) NOT NULL,
    weapon VARCHAR2(200)
);

ALTER TABLE murdermystery ADD CHECK ( year BETWEEN 1920 AND 2024 );

ALTER TABLE murdermystery ADD CONSTRAINT murdermystery_pk PRIMARY KEY ( title,
                                                                        year );

CREATE TABLE starsin (
    movietitle VARCHAR2(100) NOT NULL,
    movieyear  NUMBER(4) NOT NULL,
    starno     CHAR(13) NOT NULL,
    gurantee   NUMBER(30)
);

ALTER TABLE starsin ADD CHECK ( movieyear BETWEEN 1920 AND 2024 );

ALTER TABLE starsin ADD CHECK ( starno LIKE '010-____-____' );

ALTER TABLE starsin
    ADD CONSTRAINT starsin_pk PRIMARY KEY ( movietitle,
                                            movieyear,
                                            starno );

CREATE TABLE studio (
    name    VARCHAR2(50) NOT NULL,
    phoneno CHAR(13),
    presno  CHAR(13)
);

ALTER TABLE studio ADD CHECK ( phoneno LIKE '010-____-____' );

ALTER TABLE studio ADD CHECK ( presno LIKE '010-____-____' );

CREATE UNIQUE INDEX studio__idx ON
    studio (
        presno
    ASC );

ALTER TABLE studio ADD CONSTRAINT studio_pk PRIMARY KEY ( name );

ALTER TABLE cartoon
    ADD CONSTRAINT cartoon_of FOREIGN KEY ( title,
                                            year )
        REFERENCES movie ( title,
                           year );

ALTER TABLE contracts
    ADD CONSTRAINT contract_movie FOREIGN KEY ( title,
                                                year )
        REFERENCES movie ( title,
                           year );

ALTER TABLE contracts
    ADD CONSTRAINT contract_star FOREIGN KEY ( starno )
        REFERENCES moviestar ( info.s_no );

ALTER TABLE contracts
    ADD CONSTRAINT contract_studio FOREIGN KEY ( studioname )
        REFERENCES studio ( name );

ALTER TABLE crew
    ADD CONSTRAINT crew_of FOREIGN KEY ( studioname )
        REFERENCES studio ( name );

ALTER TABLE murdermystery
    ADD CONSTRAINT murder_of FOREIGN KEY ( title,
                                           year )
        REFERENCES movie ( title,
                           year );

ALTER TABLE address
    ADD CONSTRAINT officeof FOREIGN KEY ( studioname )
        REFERENCES studio ( name );

ALTER TABLE movie
    ADD CONSTRAINT owns FOREIGN KEY ( studioname )
        REFERENCES studio ( name );

ALTER TABLE studio
    ADD CONSTRAINT runs FOREIGN KEY ( presno )
        REFERENCES movieexec ( info.e_no );

ALTER TABLE movie
    ADD CONSTRAINT sequel_of FOREIGN KEY ( origintitle,
                                           originyear )
        REFERENCES movie ( title,
                           year );

ALTER TABLE starsin
    ADD CONSTRAINT starsin_movie_fk FOREIGN KEY ( movietitle,
                                                  movieyear )
        REFERENCES movie ( title,
                           year );

ALTER TABLE starsin
    ADD CONSTRAINT starsin_moviestar_fk FOREIGN KEY ( starno )
        REFERENCES moviestar ( info.s_no );

CREATE OR REPLACE TRIGGER fknto_studio BEFORE
    UPDATE OF presno ON studio
    FOR EACH ROW
BEGIN
    IF :old.presno IS NOT NULL THEN
        raise_application_error(-20225, 'Non Transferable FK constraint Runs on table Studio is violated');
    END IF;
END;
/



-- Oracle SQL Developer Data Modeler 요약 보고서: 
-- 
-- CREATE TABLE                            10
-- CREATE INDEX                             1
-- ALTER TABLE                             42
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           1
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   4
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- TSDP POLICY                              0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
